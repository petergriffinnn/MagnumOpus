package org.firstinspires.ftc.teamcode._TeleOPs;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;

@Disabled
@TeleOp(name = "ControlledChaosNotAwesome" , group = "A")


public class workshopTeleopRevised extends LinearOpMode {

//    private DcMotor FLW;
//    private DcMotor FRW;
//    private DcMotor BRW;
//    private DcMotor BLW;
//    private DcMotor CaroW;
//    private DcMotor Intake;
//    private DcMotor Arm;
//    private Servo Flipper;
    private ColorSensor greg;

    @Override
    public void runOpMode() {

//        FRW = hardwareMap.dcMotor.get("FRW");
//        FLW = hardwareMap.dcMotor.get("FLW");
//        BRW = hardwareMap.dcMotor.get("BRW");
//        BLW = hardwareMap.dcMotor.get("BLW");
//        CaroW = hardwareMap.dcMotor.get("CaroW");
//        Intake = hardwareMap.dcMotor.get("Intake");
//        Flipper = hardwareMap.servo.get("Flipper");
//        Arm = hardwareMap.dcMotor.get("Arm");
        greg = hardwareMap.colorSensor.get("greg");

        waitForStart();
        while (!isStopRequested()) {
            int Red = greg.red();
            int Green = greg.green();
            int Blue = greg.blue();
            while (1 == 1) {

                telemetry.addData("Red", Red);
                telemetry.addData("Blue", Blue);
                telemetry.addData("Green", Green);

                if (Red > Green && Red > Blue) {

                    telemetry.addLine("Red");

                } else if (Green > Red && Green > Blue) {

                    telemetry.addLine("Green");

                } else if (Blue > Red && Blue > Green) {

                    telemetry.addLine("Blue");
                } else {
                    telemetry.addLine("Put the word nothing");

                }
                telemetry.update();
            }
        }
    }
}



