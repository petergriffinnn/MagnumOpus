package org.firstinspires.ftc.teamcode._TeleOPs;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;

import java.util.concurrent.ArrayBlockingQueue;

@Disabled
@TeleOp(name = "ControlledChaos" , group = "A")


public class workshopTeleop extends LinearOpMode {

    private DcMotor FLW;
    private DcMotor FRW;
    private DcMotor BRW;
    private DcMotor BLW;


    @Override
    public void runOpMode() {

        FRW = hardwareMap.dcMotor.get("FRW");
        FLW = hardwareMap.dcMotor.get("FLW");
        BRW = hardwareMap.dcMotor.get("BRW");
        BLW = hardwareMap.dcMotor.get("BLW");


        waitForStart();
        while (!isStopRequested()) {
            if (gamepad1.left_stick_y > .1) { //LEFT FORWARD
                FLW.setPower(1);
                BLW.setPower(1);
                telemetry.addLine("Forward left wheel");
            } else {
                FLW.setPower(0);
                BLW.setPower(0);
                telemetry.addLine("Neutral");
            }
            if (-gamepad1.left_stick_y > .1) { //LEFT BACKWARD
                FLW.setPower(-1);
                BLW.setPower(-1);
                telemetry.addLine("Back");
            } else {
                FLW.setPower(0);
                BLW.setPower(0);
                telemetry.addLine("neutral");
            }
            if (gamepad1.right_stick_y > .1) {
                FRW.setPower(1);
                BRW.setPower(1);
                telemetry.addLine("right");
            } else if (-gamepad1.right_stick_y > .1) {
                FRW.setPower(-1);
                BRW.setPower(-1);
                telemetry.addLine("left");
            } else{
                FRW.setPower(0);
                BRW.setPower(0);
                telemetry.addLine("neutral");
            }


            if (gamepad1.left_trigger > 0) {
                FRW.setPower(0.9);
                BRW.setPower(-0.9);
                FLW.setPower(0.9);
                BLW.setPower(-0.9);
                telemetry.addLine("strafe????");
            } else {
                FRW.setPower(0);
                BRW.setPower(0);
                FLW.setPower(0);
                BLW.setPower(0);
                telemetry.addLine("neutral");
            }
            if (gamepad1.right_trigger > 0) {
                FRW.setPower(-0.9);
                BRW.setPower(0.9);
                FLW.setPower(-0.9);
                BLW.setPower(0.9);
                telemetry.addLine("strafe????");
            } else {
                FRW.setPower(0);
                BRW.setPower(0);
                FLW.setPower(0);
                BLW.setPower(0);
                telemetry.addLine("neutral");
            }




        }
    }
}



