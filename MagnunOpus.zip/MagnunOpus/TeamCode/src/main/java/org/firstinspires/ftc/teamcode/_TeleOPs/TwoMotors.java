//package org.firstinspires.ftc.teamcode._TeleOPs;
//
//import static com.sun.tools.javac.jvm.ByteCodes.error;
//
//import com.arcrobotics.ftclib.controller.PIDController;
//import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
//import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
//import com.qualcomm.robotcore.hardware.CRServo;
//import com.qualcomm.robotcore.hardware.DcMotor;
//import com.qualcomm.robotcore.hardware.DcMotorEx;
//import com.qualcomm.robotcore.hardware.DcMotorSimple;
//import com.qualcomm.robotcore.hardware.HardwareMap;
//import com.qualcomm.robotcore.hardware.Servo;
//import com.qualcomm.robotcore.util.ElapsedTime;
//
////import org.firstinspires.ftc.teamcode.subsystems.Slides;
//
//
//@TeleOp
//public class
//TwoMotors extends LinearOpMode {
//
//    //Motors
//    private DcMotor one;
//    private DcMotor two;
//
////    private DcMotor Intake;
////    private DcMotor leftTower;
////    private DcMotor rightTower;
//
//    //    //Servos
////    private Servo pp;
////    private Servo emo;
////    private Servo girl;
////    private Servo adj;
////    private Servo grimace;
//
//    public void runOpMode() throws InterruptedException {
//
//        //Motors
//        DcMotor one = hardwareMap.dcMotor.get("one");
//        DcMotor two = hardwareMap.dcMotor.get("two");
//
//
//
////        DcMotor Intake = hardwareMap.dcMotor.get("Intake");
////        DcMotor Slide = hardwareMap.dcMotor.get("Slide");
////
////        DcMotor leftTower = hardwareMap.dcMotor.get("leftTower");
////        DcMotor rightTower = hardwareMap.dcMotor.get("rightTower");
//
//        //Servos
////        Servo pp = hardwareMap.servo.get("pp"); //paper plane
////        Servo emo = hardwareMap.servo.get("emo");
////        Servo girl = hardwareMap.servo.get("girl");
////        Servo adj = hardwareMap.servo.get("adj");
////        grimace = hardwareMap.servo.get("grimace");
//
//
//        //  adj.setPosition(.2);
//
//
//        waitForStart();
//        while (opModeIsActive()) {
//
//            if (gamepad1.square) {
//                one.setPower(1);
//                two.setPower(-1);
//            } else if (gamepad1.circle) {
//                one.setPower(-1);
//                two.setPower(1);
//            } else {
//                one.setPower(0);
//                two.setPower(0);
//            }
//        }
////       }     if(gamepad2.options){
////                stage = "REST";
////                pidOn = true;
////            }
////            if(gamepad2.share){
////                stage = "SCORE";
////                pidOn = true;
////
////            }
//
//
//        //Flipper-
////            if(gamepad2.touchpad){
////               emo.setPosition(.17); //increasing value makes it more down
////               girl.setPosition(.17);
////            }
////            if(gamepad2.triangle){
////
////
////                emo.setPosition(.19);
////                girl.setPosition(.19);
////
////            } else if (gamepad2.cross){
////
////                girl.setPosition(.42);
////                emo.setPosition(.42);
////
////            }
////
////
////            if (gamepad1.circle){
////                grimace.setPosition(0);
////            } else if (gamepad1.triangle) {
////                grimace.setPosition(.7);
////            }
////            // OUT TAKE ADJ
////            if(gamepad2.dpad_down){
////                adj.setPosition(.6);
////
////            } else if(gamepad2.dpad_up){
////                adj.setPosition(.06);
////
////            } else if(gamepad2.dpad_right){
////                adj.setPosition(.3);
////
////            } else if (gamepad2.dpad_left){
////                adj.setPosition(.85);
////
////            }
////
////            //Drone
////            if (gamepad2.square){
////                pp.setPosition(.7);
////            } else if (gamepad2.circle){
////                pp.setPosition(.9);
////            }
//
//        //SLIDE
////            if(gamepad2.left_stick_y > .1){
////                Slide.setPower(-.7);
////                //pidOn = false;
////
////            } else if (-gamepad2.left_stick_y > .1) {
////                Slide.setPower(.7);
////                //pidOn = false;
////
////
////
//////            }else if(pidOn){
//////                moveToStage(stage);
////           } else {
////                Slide.setPower(0);
//////                pidOn = false;
////            }
//
//
////            if(gamepad2.right_stick_y > .1){
////                Slide.setPower(-.7);
////                //pidOn = false;
////
////            } else if (-gamepad2.right_stick_y > .1) {
////                Slide.setPower(.7);
////                //pidOn = false;
////
////
////
//////            }else if(pidOn){
//////                moveToStage(stage);
////            } else {
////                Slide.setPower(0);
//////                pidOn = false;
////            }
////
////            //HANGING
////            if(gamepad1.left_bumper){
////                rightTower.setPower(-.9);
////                leftTower.setPower(-.9);
////
////            } else if (gamepad1.right_bumper){
////                rightTower.setPower(.9);
////                leftTower.setPower(.9);
////
////            } else {
////                rightTower.setPower(0);
////                leftTower.setPower(0);
////
////            }
////
////            if (getRuntime() > 85 && getRuntime() < 90) {
////
////                gamepad1.rumble(50, 50, 50);
////                gamepad2.rumble(80, 80, 50);
////            }
////
////            telemetry.addData("Diego Time Elapsed", getRuntime());
////            telemetry.update();
////
////        }
//
//
//    }
//}
//
