//package org.firstinspires.ftc.teamcode._TeleOPs;
//
//import com.arcrobotics.ftclib.controller.PIDController;
//import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
//import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
//import com.qualcomm.robotcore.hardware.CRServo;
//import com.qualcomm.robotcore.hardware.DcMotor;
//import com.qualcomm.robotcore.hardware.DcMotorEx;
//import com.qualcomm.robotcore.hardware.DcMotorSimple;
//import com.qualcomm.robotcore.hardware.HardwareMap;
//import com.qualcomm.robotcore.hardware.Servo;
//import com.qualcomm.robotcore.util.ElapsedTime;
//
//import org.firstinspires.ftc.teamcode.subsystems.Slides;
//
//
//@TeleOp
//public class TeachingTele extends LinearOpMode {
//
//    //Motors
//    private DcMotor FRW;
//    private DcMotor FLW;
//    private DcMotor BRW;
//    private DcMotor BLW;
//    private DcMotor Intake;
//    private DcMotor leftTower;
//
//
//
//
//
//
//    String stage = "GROUND";
//
//
//    public void delivery(HardwareMap hardwareMap) {
//
//
//
//
//
//
//
//
//
//    }
//
//    public void stall() {
//
//        Slide.setPower(0.1);
//
//    }
//
//    private DcMotor Slide;
//
//
//    private PIDController controller;
//
//    public void extend(double liftSpeed) {
//
//        Slide.setPower(Math.abs(liftSpeed));
//
//
//    }
//
//    public void retract(double slideSpeed) {
//
//        Slide.setPower(-Math.abs(slideSpeed));
//
//
//    }
//
//
//    public void moveToStage(String stage) {
//
//        int slidePosition = Slide.getCurrentPosition();
//
//        int Position[] = {145, 1000};
//        String Stage[] = {"REST", "SCORE"};
//
//        int stageIndex = Byte.MAX_VALUE;
//        int res = 0;
//
//
//        for (int i = 0; i < Stage.length; i++) {
//
//            if (Stage[i].equals(stage)) {
//                stageIndex = i;
//                break;
//            }
//        }
//
//        if (stageIndex != Byte.MAX_VALUE) {
//
//            res = Position[stageIndex];
//            double pid = controller.calculate(slidePosition, res);
//
//            int error = res - slidePosition;
//
//            double power = pid + 0.1;
//
//            if (Math.abs(error) > 100) {
//
//                Slide.setPower(power);
//
//
//
//
//            }
//
//
//
//        }
//    }
//
//
//    public void reset(){
//
//        Slide.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
//        Slide.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
//
//    }
//    public void runOpMode() throws InterruptedException {
//
//        //Motors
//        DcMotor FRW = hardwareMap.dcMotor.get("FRW");
//        DcMotor FLW = hardwareMap.dcMotor.get("FLW");
//        DcMotor BRW = hardwareMap.dcMotor.get("BRW");
//        DcMotor BLW = hardwareMap.dcMotor.get("BLW");
//
//
//
//        boolean pidOn = true;
//        //Wait for start loop (probanbly)
//
//
//
//        delivery(hardwareMap);
//        DcMotor Intake = hardwareMap.dcMotor.get("Intake");
//        DcMotor Slide = hardwareMap.dcMotor.get("Slide");
//
//        DcMotor leftTower = hardwareMap.dcMotor.get("leftTower");
//        DcMotor rightTower = hardwareMap.dcMotor.get("rightTower");
//
//        //Servos
//        Servo pp = hardwareMap.servo.get("pp"); //paper plane
//        Servo emo = hardwareMap.servo.get("emo");
//        Servo girl = hardwareMap.servo.get("girl");
//        Servo adj = hardwareMap.servo.get("adj");
//
//
//        FLW.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
//        BLW.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
//        FRW.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
//        BRW.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
//
//        BRW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//        FRW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//        BLW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//        FLW.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//        FRW.setDirection(DcMotorSimple.Direction.REVERSE);
//        BRW.setDirection(DcMotorSimple.Direction.REVERSE);
//        girl.setDirection(Servo.Direction.REVERSE);
//        //  adj.setPosition(.2);
//
//
//        waitForStart();
//        while (opModeIsActive()){
//
//            double y = -gamepad1.left_stick_y; // Remember, this is reversed
//            double x = gamepad1.left_stick_x; // Counteract imperfect strafing
//            double rx = .8 * (gamepad1.right_stick_x);
//
//
//            double i = 0;
//            double denominator = Math.max(Math.abs(y) + Math.abs(x) + Math.abs(rx), 1);
//            double frontLeftPower = (y + x + rx) / denominator;
//            double backLeftPower = (y - x + rx) / denominator;
//            double frontRightPower = (y - x - rx) / denominator;
//            double backRightPower = (y + x - rx) / denominator;
//
//            FLW.setPower(frontLeftPower * -1);
//            BLW.setPower(backLeftPower * -1);
//            FRW.setPower(frontRightPower * -1);
//            BRW.setPower(backRightPower * -1);
//
//            //INTAKE
//            if(gamepad2.right_bumper){
//                Intake.setPower(.75);
//
//            } else if (gamepad2.left_bumper){
//                Intake.setPower(-.75);
//
//
//            } else {
//                Intake.setPower(0);
//
//
//            }
//            }
//
//
//            //HANGING
//            if(gamepad1.left_bumper){
//                leftTower.setPower(-.9);
//                leftTower.setPower(-.9);
//
//            } else if (gamepad1.right_bumper){
//                leftTower.setPower(.9);
//                leftTower.setPower(.9);
//
//            } else {
//                leftTower.setPower(0);
//                leftTower.setPower(0);
//
//            }
//
//            if (getRuntime() > 85 && getRuntime() < 90) {
//
//                gamepad1.rumble(50, 50, 50);
//                gamepad2.rumble(80, 80, 50);
//            }
//
//            telemetry.addData("Diego Time Elapsed", getRuntime());
//            telemetry.update();
//
//        }
//
//
//    }
//
//
//
