package org.firstinspires.ftc.teamcode._TeleOPs;
import static org.firstinspires.ftc.robotcore.external.BlocksOpModeCompanion.gamepad1;
import static org.firstinspires.ftc.robotcore.external.BlocksOpModeCompanion.hardwareMap;

import android.graphics.Color;
import android.hardware.Sensor;
import android.os.VibrationEffect;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.NormalizedRGBA;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;

import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

@Disabled
@TeleOp
public class SussyExamination4 extends LinearOpMode {

    //private Servo Sus1;
   // private Servo Sus2;
   // private Servo Sus3D;


    public void runOpMode() throws InterruptedException {

//        Sus1 = hardwareMap.servo.get("Sus1");
//        Sus2 = hardwareMap.servo.get("Sus2");
//        Sus3D = hardwareMap.servo.get("Sus3D");
        while (!isStopRequested()) {
//Im going to kms tommorow at 2:30 PM
            if (gamepad1.triangle) {
//                Sus1.setPosition(.6);
//                Sus2.setPosition(.4);
//                //poop
            } else if (gamepad1.cross){
//                Sus1.setPosition(-.6);
//                Sus2.setPosition(.6);
            } else{
//                Sus1.setPosition(.5);
//                Sus2.setPosition(.5);
            }
            if (gamepad1.dpad_up) {
//                Sus3D.setPosition(.4);
            } else if (gamepad1.dpad_down){
//                Sus3D.setPosition(0);

            }
        }
    }
}