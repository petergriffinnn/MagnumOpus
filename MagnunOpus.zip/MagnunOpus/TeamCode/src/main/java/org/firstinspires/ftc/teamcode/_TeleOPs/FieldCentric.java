//package org.firstinspires.ftc.teamcode._TeleOPs;
//
//import com.qualcomm.hardware.bosch.BNO055IMU;
//import com.qualcomm.hardware.bosch.BNO055IMUNew;
//import com.qualcomm.robotcore.eventloop.opmode.Disabled;
//import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
//import com.qualcomm.robotcore.hardware.DcMotor;
//import com.qualcomm.robotcore.hardware.DcMotorEx;
//import com.qualcomm.robotcore.hardware.DistanceSensor;
//import com.qualcomm.robotcore.hardware.ColorSensor;
//import com.qualcomm.robotcore.hardware.IMU;
//import com.qualcomm.robotcore.util.ElapsedTime;
//import com.qualcomm.robotcore.hardware.DcMotorSimple;
//import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
//
//
//
//import com.qualcomm.hardware.bosch.BHI260IMU;
//import com.qualcomm.hardware.bosch.JustLoggingAccelerationIntegrator;
//@Disabled
//@TeleOp
//
//public class FieldCentric extends LinearOpMode {
//
//    BHI260IMU imu;
//
//
//    private ElapsedTime runtime = new ElapsedTime();
//
//    private DcMotorEx FRW;
//    private DcMotorEx FLW;
//    private DcMotorEx BRW;
//    private DcMotorEx BLW;
//
//
//
//
//    String stage = "GROUND";
//
//    public void runOpMode() throws InterruptedException {
//
//        BHI260IMU.Parameters parameters = new BHI260IMU.Parameters();
//        parameters.angleUnit           = BHI260IMU.AngleUnit.DEGREES;
//        parameters.accelUnit           = BHI260IMU.AccelUnit.METERS_PERSEC_PERSEC;
//        parameters.calibrationDataFile = "BHI260IMUCalibration.json"; // see the calibration sample opmode
//        parameters.loggingEnabled      = true;
//        parameters.loggingTag          = "IMU";
//        parameters.accelerationIntegrationAlgorithm = new JustLoggingAccelerationIntegrator();
//
//        imu = hardwareMap.get(BHI260IMU.class, "imu");
//        imu.initialize(parameters);
//
//        FRW  = hardwareMap.get(DcMotorEx.class, "FRW");
//        BRW = hardwareMap.get(DcMotorEx.class, "BRW");
//        FLW  = hardwareMap.get(DcMotorEx.class, "FLW");
//        BLW = hardwareMap.get(DcMotorEx.class, "BLW");
//
//
//        FRW.setDirection(DcMotorSimple.Direction.REVERSE);
//        BRW.setDirection(DcMotorSimple.Direction.REVERSE);
//        FLW.setDirection(DcMotorSimple.Direction.FORWARD);
//        BLW.setDirection(DcMotorSimple.Direction.FORWARD);
//
//
//        FRW.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
//        BRW.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
//        FLW.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
//        BLW.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
//
//
//        FRW.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
//        BRW.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
//        FLW.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
//        BLW.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
//
//
//        FRW.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
//        BRW.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
//        FLW.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
//        BLW.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
//
//
//
//
//
//        byte i = 0;
//        byte q = 0;
//
//        boolean pidOn = true;
//
//        waitForStart();
//        if (isStopRequested()) return;
//        while (opModeIsActive()) {
//
//            double angle = Math.toRadians(imu.getAngularOrientation().firstAngle);
//
//            telemetry.addData("angle", Math.toDegrees(angle));
//            telemetry.update();
//
//            if(gamepad1.options && q==0){
//                imu.initialize(parameters);
//            }
//
//
//            double y = -gamepad1.left_stick_y;
//            double x = gamepad1.left_stick_x * 1.1;
//            double rx = gamepad1.right_stick_x;
//
//            double rotx = x*Math.cos(-angle) - y*Math.sin(-angle);
//            double roty = x*Math.sin(-angle) + y*Math.cos(-angle);
//
//            double denominator = Math.max(Math.abs(roty) + Math.abs(rotx) + Math.abs(rx), 1);
//
//            double pFrontRight = (roty + rotx + rx) / denominator;
//            double pBackRight = (roty - rotx + rx) / denominator;
//            double pFrontLeft = (roty - rotx - rx) / denominator;
//            double pBackLeft = (roty + rotx - rx) / denominator;
//
//
//
//
//
//        }
//
//    }
//}
